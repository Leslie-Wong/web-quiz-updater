<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */

$this->title = '覆查模擬考試';

$css = "
    body{
        background-color: #eee !important;
    }
    .optionRow {
        -moz-box-shadow:inset 0px 6px 18px 0px #ffffff;
        -webkit-box-shadow:inset 0px 6px 18px 0px #ffffff;
        box-shadow:inset 0px 6px 18px 0px #ffffff;
        background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #ffffff), color-stop(1, #f6f6f6));
        background:-moz-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
        background:-webkit-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
        background:-o-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
        background:-ms-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
        background:linear-gradient(to bottom, #ffffff 5%, #f6f6f6 100%);
        filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#f6f6f6',GradientType=0);
        background-color:#ffffff;
        -moz-border-radius:3px;
        -webkit-border-radius:3px;
        border-radius:3px;
        border:1px solid #dcdcdc;
        display:inline-block;
        color:#666666;
        font-family:Arial;
        font-size:16px;
        font-weight:bold;
        padding-top:10px;
        /*text-decoration:none;*/
        /*text-shadow:0px 1px 0px #ffffff;*/
        width:95%;
        margin-bottom:10px;
        padding-left: 20px;
    }    
    .active {
        background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #fff368), color-stop(1, #fcffbb ));
        background:-moz-linear-gradient(top, #fff368 5%, #fcffbb  100%);
        background:-webkit-linear-gradient(top, #fff368 5%, #fcffbb  100%);
        background:-o-linear-gradient(top, #fff368 5%, #fcffbb  100%);
        background:-ms-linear-gradient(top, #fff368 5%, #fcffbb  100%);
        background:linear-gradient(to bottom, #fff368 5%, #fcffbb  100%);
        filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#fff368', endColorstr='#fcffbb ',GradientType=0);
        background-color:#fff368;
    }
    .topic-content-row{
        background-color: white;
        font-size: 17px;
        border-radius: 6px;
        font-weight: bold;
        margin-bottom: 10px;
        padding: 5px;
        width: 95%;
    }
    .topic-content-row img{
        margin-bottom: 5px;
    }
    .navbar-inverse{
        display:none;
    }
    .container{
        padding: 0px !important;
    }
    .left-row{
        float: left;
        width: 70%;
    }
    .right-row{
        float: right;
        width: 30%;
        height: 610px;
        background-color: white;
        padding: 5px;
        border-radius: 5px;
    }    
    .right-wrap{
        background-color: #cfdcff;
        display: flex;
        width: 100%;
        min-height: 600px;
        border-radius: 5px;
        flex: 1;
        flex-direction: column;
        padding-left: 10px;
        padding-top: 5px;
    }
    .icons{
        display: flex;
        flex: 0.1;
        flex-wrap: wrap;
    }
    .icon{
        width: 35px;
        height: 35px;
        float: left;
        line-height: 35px;
        text-align: center;
        vertical-align: middle;
        margin: 5px;
        background-color: #aaa7da;
        color: #080027;
        font-size: 16px;
        border-radius: 20px;
        cursor: pointer;
    }
    .icon-d{
        display: flex;
        flex-direction: row;
        flex: 1;
        justify-content: flex-start;
        align-items: flex-end;
    }
    .icon-d .icon{
        width: 20px;
        height: 20px;
        line-height: 20px;
        border-radius: 10px;
    }
    .icon-d span{
        padding-top: 5px;
        display: block;
        font-size: 15px;
    }
    .icons .icon:hover{
        background-color: #f9fb8d;
    }
    .isAnswered{
        background-color: #00FF00;
    }
    .isWrong{
        background-color: #FF0000;
    }
    .isHover{
        background-color: #f9fb8d;
    }
    .body-content{
        display: flex; 
    }
    .wrap > .container {
        padding: 0px 0px 0px 0px;
        margin-bottom: 10px;
    }
    #up{
        display:none;
        float: left;
    }
    #next{
        float: right;
    }
    #submit{
        float: right;
        width:120px;
        margin-right: 5px;
    }   
    .btn-list .gettopic{
        width:120px;
    }
    .btn-list{
        width: 95%;
    }
    .messi-content h2{
        text-align: center;
        margin-top: 6px;
    }
    .unselectable {
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
";
$this->registerCss($css);

$baseUrl=Yii::$app->request->baseUrl;

$js = <<< JS

    
    var qid = 0;
    window['isSubmit']=false;
    //var answered = {};

    document.addEventListener('contextmenu', event => event.preventDefault());
    $('#icon-'+qid).addClass('isHover');
   /*
    $('body').on('submit', 'form', function() {
        console.log('asdasd');
    });
    */
    $('.gettopic').click(function(){   
        var dialog = new Messi(
            "<h2>資料載入中，請稍後！</h2>",
            {modal: true, closeButton:false}
        );        

        $.ajax({
            url: '$baseUrl/index.php?r=result%2Fnext',
            type: 'post',
            data: {
                        'id': $(this).data('id') , 
                        'q': qid, 
                    },
            success: function (data) {
                if(window['isSubmit']){                        
                       window.location.replace('$baseUrl/index.php?r=quiz%2Fsubmit');
                }else{
                    $('#icon-'+qid).removeClass('isHover');
                    var page = parseInt(data.page);
                    var max = parseInt(data.max);
                    $('#qc').html(page+1);
                    $('#up').data('id',page-1);
                    $('#up').data('q',page);
                    $('#next').data('id',page+1);
                    $('#next').data('q',page);
                    qid = page;
                    name = data.data.name.replace(/\\r\\n|\\r|\\n/g,"<br />");
                    $('#topic-content').html(name);

                    $('#icon-'+qid).addClass('isHover');

                    if(data.data.img!=""){
                        $('.topic-img').html('<img src="../'+data.data.img+'" />');
                    }else{
                         $('.topic-img').html('');
                    }

                    var showTrueMsg="回答錯誤！ ";
                    var showTrueAns="";

                    $('.topic-options').html('');
                    var i=10;
                    $.each(data.data.options,function( index, val ) {
                        var act='';
                        var key=i.toString(16).toUpperCase();                        
                        if(val["isTrue"]=="T"){
                            showTrueAns=" 正確答案：【"+key+"】";

                            if(data.answered == ""){
                                showTrueMsg="未作答！ ";
                            }else if(data.answered == key){
                                showTrueMsg="回答正確！ ";
                            }
                        }
                        if(data.answered == key){
                            act=' active';
                        }
                        $('.topic-options').append('<div class="optionRow '+act+'" data-o="'+key+'" >'+ 
                                '<div class="quizName" style="margin-bottom:10px">'+key+':  '+val["name"]+'</div>'+                           
                            '</div>');
                        i++;
                    });

                    $('.ans').html(showTrueMsg+showTrueAns);

                    if(page==0){
                        $('#up').hide();
                    }else{
                        $('#up').show();
                    }

                    if(page+1==max){
                        $('#next').hide();
                    }else{
                        $('#next').show();
                    }

                    window['isSubmit'] = false;
                    
                    a=data.answered?data.answered:undefined;

                    setTimeout(function(){ 
                           dialog.unload(); 
                    }, 500);
                }

            },
            error: function (err){
                 console.log(err);
                 dialog.unload();
            }
        });
    });

JS;
$this->registerJS($js);

$r=$w=$n=0;

?>
<div class="site-index">
    <?php /*
    <div class="jumbotron">
        <h1><?= Html::encode($data['name']); ?></h1>

        <?= Html::a('next', ['next', 'id'=>($page+1)], ['class' => 'btn btn-success']) ?>

        <p class="lead">You have successfully created your Yii-powered application.</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Get started with Yii</a></p>
    </div>
    */
    //var_dump($answered);
    ?>

    <?php if (Yii::$app->session->hasFlash('success')): ?>
    <div id="my-flash-msg" class="alert alert-success alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
    <?= Yii::$app->session->getFlash('success', null, true) ?>
    </div>
    <?php endif; ?>
    
    <script>
        //setTimeout($("#my-flash-msg").animate({opacity: 0.4}, 4000 ),2000);
       setTimeout('$("#my-flash-msg").animate({opacity: 0}, 1000 ).animate({height: 0}, 200 ).fadeOut();',4000);
    </script>

    <div class="body-content">

        <div class="left-row">
            <?php $form = ActiveForm::begin([
                'action' => ['quiz/submit'],
                'id' => 'form1',
            ]); ?>
            <input type="hidden" name="val" value="1">
            <?php ActiveForm::end(); ?>
            <div class="topic-heading unselectable" style="display: flex;align-items: center;">
                <h2 class="unselectable" style="flex: 0.9;">第<span id="qc"><?= Html::encode($page+1); ?></span>題：<br/></h2>
                <div class="ans unselectable" style="
                        font-size: 20px;
                        color: red;
                "><?php 
                if($answered!=""){ 
                    echo $answered[0]==$answered[1]?"回答正確！ ":"回答錯誤！ ";
                }else{
                    echo  "未作答！ ";
                }   
                $t = "";
                $j = 41;
                for($i=0;$i<sizeof($data['options']);$i++){
                    if($data['options'][$i]['isTrue']=="T"){
                        $t = hex2bin($j);
                    }
                    $j++;
                }         
                echo "正確答案：【".$t."】"; 
                ?></div>
            </div>
            <div class="topic-content-row unselectable">                
                <div class="topic-img" id="topic-img unselectable"> 
                    <?php if($data['img']){ ?>
                        <img src="../<?= Html::encode($data['img']); ?>" />                    
                    <?php } ?>
                </div>
                <div class="topic-content unselectable" id="topic-content"> 
                    <?= Html::encode($data['name']); ?>
                </div>
            </div>
            <div class="topic-options unselectable">
                <?php 
                    $i=41;
                    foreach($data['options'] as $option){ ?>
                        <div class="optionRow unselectable <?php if(isset($answered[0]) && $answered[0]==hex2bin($i)) echo 'active' ?>" data-o="<?php echo hex2bin($i) ?>" >    
                            <div class="quizName unselectable" style="margin-bottom:10px"><?php echo hex2bin($i).": " ?><?= Html::encode($option['name']); ?></div>                            
                        </div>   
                <?php $i++; } ?>
            </div>
            <div class="btn-list">  
                    <div id="up" class="btn btn-success gettopic" data-id="<?= Html::encode($page-1); ?>">上一題</div>
                    <div id="next" class="btn btn-success gettopic" data-id="<?= Html::encode($page+1); ?>">下一題</div>
                    <div id="submit" class="btn btn-success" onClick="window.history.back();" data-id="<?= Html::encode($page+1); ?>">返 回</div>
            </div>
        </div>
        <script>
            function toSubmit(){
                window['isSubmit'] = true;
            }
        </script>

        <div class="right-row">
            <div class="right-wrap">
                <div class="icons">
                    <?php for($i=0; $i < intval($max); $i++) { 
                        $c = "";
                        if(isset($ans["q".$i])){
                            if($ans["q".$i][0]==$ans["q".$i][1]){
                                $c = "isAnswered";
                                $r++;
                            }else{
                                $c = "isWrong";
                                $w++;
                            }
                        }else{
                            $n++;
                        }
                    ?>
                        <div class="icon gettopic <?php echo $c ?>" id="icon-<?php echo $i ?>" data-id="<?php echo $i ?>"><?php echo $i+1 ?></div>
                    <?php } ?>
                </div>
                <div class="icon-d">
                    <div style="display: flex;flex-direction: column;">
                        <div style="width: 140px;"><div class="icon isHover"></div><span>查看中</span></div>
                        <div><div class="icon "></div><span>未作答 (<?php echo $n ?>)</span></div>
                    </div>
                    <div style="display: flex;flex-direction: column;">
                        <div style="width: 130px;"><div class="icon isAnswered"></div><span>正確 (<?php echo $r ?>)</span></div>
                        <div><div class="icon isWrong"></div><span>錯誤 (<?php echo $w ?>)</span></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
